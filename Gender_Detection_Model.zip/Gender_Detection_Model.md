# Gender Classification using Neural Networks

## Importing dependencies


```python
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import BatchNormalization, Conv2D, MaxPooling2D, Activation, Flatten, Dropout, Dense
from tensorflow.keras import backend as K
from tensorflow.keras.callbacks import LearningRateScheduler
import tensorflow as tf
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.applications import VGG16
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.models import Model
import os
import random
import cv2
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, precision_recall_curve, roc_curve, auc, classification_report
import numpy as np
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.models import load_model
from sklearn.model_selection import train_test_split
```

## EDA


```python
men_folder = './Model Enhancement/Dataset preparation/Gender Dataset (16-60)/man'
women_folder = './Model Enhancement/Dataset preparation/Gender Dataset (16-60)/woman'

# Get a random sample of file names from each folder
men_image_files = random.sample(os.listdir(men_folder), 5)
women_image_files = random.sample(os.listdir(women_folder), 5)

# Read and plot the random sample of images
fig, axes = plt.subplots(2, 5, figsize=(15, 6))
for i, image_file in enumerate(men_image_files):
    img_path = os.path.join(men_folder, image_file)
    men_images = cv2.imread(img_path)
    axes[0, i].imshow(cv2.cvtColor(men_images, cv2.COLOR_BGR2RGB))
    axes[0, i].axis('off')
    axes[0, i].set_title('Men')

for i, image_file in enumerate(women_image_files):
    img_path = os.path.join(women_folder, image_file)
    women_images = cv2.imread(img_path)
    axes[1, i].imshow(cv2.cvtColor(women_images, cv2.COLOR_BGR2RGB))
    axes[1, i].axis('off')
    axes[1, i].set_title('Women')

plt.show()
```


    
![png](output_4_0.png)
    



```python
men_images = [cv2.imread(os.path.join(men_folder, img)) for img in os.listdir(men_folder)[:]]
women_images = [cv2.imread(os.path.join(women_folder, img)) for img in os.listdir(women_folder)[:]]


men_image_sizes = [img.shape for img in men_images]
women_image_sizes = [img.shape for img in women_images]

men_heights = [img.shape[0] for img in men_images]
men_widths = [img.shape[1] for img in men_images]

women_heights = [img.shape[0] for img in women_images]
women_widths = [img.shape[1] for img in women_images]

plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.hist(men_heights, bins=20, alpha=0.5, label='Men')
plt.hist(women_heights, bins=20, alpha=0.5, label='Women')
plt.title('Distribution of Heights')
plt.legend()

plt.subplot(1, 2, 2)
plt.hist(men_widths, bins=20, alpha=0.5, label='Men')
plt.hist(women_widths, bins=20, alpha=0.5, label='Women')
plt.title('Distribution of Widths')
plt.legend()

plt.show()

```


    
![png](output_5_0.png)
    



```python
# Assuming men_folder and women_folder are defined
men_count = len(os.listdir(men_folder))
women_count = len(os.listdir(women_folder))

# Bar chart with styling
plt.figure(figsize=(8, 6))
bars = plt.bar(['Men', 'Women'], [men_count, women_count], color=['steelblue', 'lightcoral'])

# Add data labels on top of the bars
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval, round(yval), ha='center', va='bottom', color='black', fontsize=12)

# Add grid lines
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Title and labels
plt.title('Class Distribution', fontsize=16)
plt.xlabel('Gender', fontsize=14)
plt.ylabel('Number of Images', fontsize=14)

# Show the plot
plt.show()

```


    
![png](output_6_0.png)
    


## Data Directory


```python
data_dir = r'./Model Enhancement/Dataset preparation/Gender Dataset (16-60)'
```

## Initial Parameters


```python
img_width, img_height = 96, 96
batch_size = 64
test_split_ratio = 0.2
epochs = 35
```

## Preprocessing


```python
datagen = ImageDataGenerator(rescale=1./255, validation_split=test_split_ratio)

```

## Training Data Generator Configuration


```python
train_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='binary',  # Use 'binary' for binary classification
    subset='training',  # Specify 'training' for the training set
    shuffle=True
)
```

    Found 15446 images belonging to 2 classes.
    

## Test Data Generator Configuration


```python
test_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='binary',  # Use 'binary' for binary classification
    subset='validation',  # Specify 'validation' for the testing set
    shuffle=False  # Set to False for evaluation
)

```

    Found 3861 images belonging to 2 classes.
    

# CNN Model

## Defining a custom learning rate scheduler


```python
def lr_schedule(epoch):
    lr = 1e-3
    if epoch > 32:
        lr *= 0.5
    elif epoch > 28:
        lr *= 0.7
    elif epoch > 20:
        lr *= 0.9
    return lr

lr_scheduler = LearningRateScheduler(lr_schedule)

```


```python
# Model creation
model = Sequential()

# Convolutional layers
model.add(Conv2D(32, (3, 3), padding="same", input_shape=(img_width, img_height, 3)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(3, 3)))
model.add(Dropout(0.25))

model.add(Conv2D(64, (3, 3), padding="same"))
model.add(Activation('relu'))
model.add(BatchNormalization())

model.add(Conv2D(64, (3, 3), padding="same"))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Conv2D(128, (3, 3), padding="same"))
model.add(Activation('relu'))
model.add(BatchNormalization())

model.add(Conv2D(128, (3, 3), padding="same"))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

# Fully connected layers
model.add(Flatten())
model.add(Dense(1024))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(Dropout(0.5))

model.add(Dense(1))
model.add(Activation('sigmoid'))

```

## Model Optimization and Compilation


```python
opt = tf.keras.optimizers.legacy.Adam(learning_rate=1e-3, decay=1e-3 / epochs)
model.compile(loss="binary_crossentropy", optimizer=opt, metrics=["accuracy"])

```

## Model Training


```python
history = model.fit(train_generator, epochs=epochs, validation_data=test_generator, callbacks=[lr_scheduler])
```

    Epoch 1/35
    242/242 [==============================] - 587s 2s/step - loss: 0.4022 - accuracy: 0.8493 - val_loss: 0.6523 - val_accuracy: 0.5840 - lr: 0.0010
    Epoch 2/35
    242/242 [==============================] - 435s 2s/step - loss: 0.2214 - accuracy: 0.9160 - val_loss: 0.4250 - val_accuracy: 0.8024 - lr: 0.0010
    Epoch 3/35
    242/242 [==============================] - 425s 2s/step - loss: 0.1737 - accuracy: 0.9351 - val_loss: 0.2418 - val_accuracy: 0.9140 - lr: 0.0010
    Epoch 4/35
    242/242 [==============================] - 424s 2s/step - loss: 0.1475 - accuracy: 0.9457 - val_loss: 0.3126 - val_accuracy: 0.9150 - lr: 0.0010
    Epoch 5/35
    242/242 [==============================] - 430s 2s/step - loss: 0.1594 - accuracy: 0.9435 - val_loss: 0.4864 - val_accuracy: 0.8283 - lr: 0.0010
    Epoch 6/35
    242/242 [==============================] - 447s 2s/step - loss: 0.1228 - accuracy: 0.9564 - val_loss: 0.3356 - val_accuracy: 0.8959 - lr: 0.0010
    Epoch 7/35
    242/242 [==============================] - 437s 2s/step - loss: 0.1177 - accuracy: 0.9594 - val_loss: 0.3926 - val_accuracy: 0.8708 - lr: 0.0010
    Epoch 8/35
    242/242 [==============================] - 441s 2s/step - loss: 0.0985 - accuracy: 0.9677 - val_loss: 0.2285 - val_accuracy: 0.9195 - lr: 0.0010
    Epoch 9/35
    242/242 [==============================] - 444s 2s/step - loss: 0.1194 - accuracy: 0.9562 - val_loss: 0.3262 - val_accuracy: 0.8871 - lr: 0.0010
    Epoch 10/35
    242/242 [==============================] - 449s 2s/step - loss: 0.0924 - accuracy: 0.9685 - val_loss: 0.2209 - val_accuracy: 0.9332 - lr: 0.0010
    Epoch 11/35
    242/242 [==============================] - 436s 2s/step - loss: 0.0880 - accuracy: 0.9697 - val_loss: 0.2830 - val_accuracy: 0.9148 - lr: 0.0010
    Epoch 12/35
    242/242 [==============================] - 434s 2s/step - loss: 0.0832 - accuracy: 0.9713 - val_loss: 0.2304 - val_accuracy: 0.9270 - lr: 0.0010
    Epoch 13/35
    242/242 [==============================] - 491s 2s/step - loss: 0.0806 - accuracy: 0.9731 - val_loss: 0.2750 - val_accuracy: 0.9158 - lr: 0.0010
    Epoch 14/35
    242/242 [==============================] - 429s 2s/step - loss: 0.0844 - accuracy: 0.9721 - val_loss: 0.3351 - val_accuracy: 0.8972 - lr: 0.0010
    Epoch 15/35
    242/242 [==============================] - 524s 2s/step - loss: 0.0907 - accuracy: 0.9690 - val_loss: 0.2437 - val_accuracy: 0.9158 - lr: 0.0010
    Epoch 16/35
    242/242 [==============================] - 569s 2s/step - loss: 0.0802 - accuracy: 0.9715 - val_loss: 0.4122 - val_accuracy: 0.8824 - lr: 0.0010
    Epoch 17/35
    242/242 [==============================] - 583s 2s/step - loss: 0.0668 - accuracy: 0.9784 - val_loss: 0.3470 - val_accuracy: 0.8964 - lr: 0.0010
    Epoch 18/35
    242/242 [==============================] - 444s 2s/step - loss: 0.0590 - accuracy: 0.9804 - val_loss: 0.2713 - val_accuracy: 0.9140 - lr: 0.0010
    Epoch 19/35
    242/242 [==============================] - 433s 2s/step - loss: 0.0615 - accuracy: 0.9793 - val_loss: 0.3754 - val_accuracy: 0.9000 - lr: 0.0010
    Epoch 20/35
    242/242 [==============================] - 446s 2s/step - loss: 0.0495 - accuracy: 0.9833 - val_loss: 0.4273 - val_accuracy: 0.8977 - lr: 0.0010
    Epoch 21/35
    242/242 [==============================] - 539s 2s/step - loss: 0.0468 - accuracy: 0.9850 - val_loss: 0.2086 - val_accuracy: 0.9376 - lr: 0.0010
    Epoch 22/35
    242/242 [==============================] - 453s 2s/step - loss: 0.0513 - accuracy: 0.9831 - val_loss: 0.2533 - val_accuracy: 0.9272 - lr: 9.0000e-04
    Epoch 23/35
    242/242 [==============================] - 577s 2s/step - loss: 0.0416 - accuracy: 0.9858 - val_loss: 0.3291 - val_accuracy: 0.9135 - lr: 9.0000e-04
    Epoch 24/35
    242/242 [==============================] - 555s 2s/step - loss: 0.0449 - accuracy: 0.9835 - val_loss: 0.2780 - val_accuracy: 0.9283 - lr: 9.0000e-04
    Epoch 25/35
    242/242 [==============================] - 448s 2s/step - loss: 0.0472 - accuracy: 0.9832 - val_loss: 0.2764 - val_accuracy: 0.9280 - lr: 9.0000e-04
    Epoch 26/35
    242/242 [==============================] - 463s 2s/step - loss: 0.0343 - accuracy: 0.9885 - val_loss: 0.3649 - val_accuracy: 0.9101 - lr: 9.0000e-04
    Epoch 27/35
    242/242 [==============================] - 465s 2s/step - loss: 0.0319 - accuracy: 0.9885 - val_loss: 0.4192 - val_accuracy: 0.8954 - lr: 9.0000e-04
    Epoch 28/35
    242/242 [==============================] - 453s 2s/step - loss: 0.0268 - accuracy: 0.9910 - val_loss: 0.3270 - val_accuracy: 0.9226 - lr: 9.0000e-04
    Epoch 29/35
    242/242 [==============================] - 473s 2s/step - loss: 0.0317 - accuracy: 0.9883 - val_loss: 0.5695 - val_accuracy: 0.8814 - lr: 9.0000e-04
    Epoch 30/35
    242/242 [==============================] - 688s 3s/step - loss: 0.0206 - accuracy: 0.9930 - val_loss: 0.4140 - val_accuracy: 0.9047 - lr: 7.0000e-04
    Epoch 31/35
    242/242 [==============================] - 553s 2s/step - loss: 0.0171 - accuracy: 0.9943 - val_loss: 0.3831 - val_accuracy: 0.9226 - lr: 7.0000e-04
    Epoch 32/35
    242/242 [==============================] - 503s 2s/step - loss: 0.0203 - accuracy: 0.9940 - val_loss: 0.4976 - val_accuracy: 0.8879 - lr: 7.0000e-04
    Epoch 33/35
    242/242 [==============================] - 470s 2s/step - loss: 0.0250 - accuracy: 0.9918 - val_loss: 0.4266 - val_accuracy: 0.9029 - lr: 7.0000e-04
    Epoch 34/35
    242/242 [==============================] - 544s 2s/step - loss: 0.0238 - accuracy: 0.9917 - val_loss: 0.5823 - val_accuracy: 0.8739 - lr: 5.0000e-04
    Epoch 35/35
    242/242 [==============================] - 485s 2s/step - loss: 0.0184 - accuracy: 0.9939 - val_loss: 0.4058 - val_accuracy: 0.9176 - lr: 5.0000e-04
    

## Plotting the training and validation accuracy and loss of the CNN model


```python
# Set a seaborn style
sns.set(style="whitegrid")

# Access the training history
cnn_history_dict = history.history

# Plotting the training and validation loss
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1)
plt.plot(cnn_history_dict['loss'], label='Training Loss', color='blue', marker='o')
plt.plot(cnn_history_dict['val_loss'], label='Validation Loss', color='orange', marker='o')
plt.title('CNN Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)

# Plotting the training and validation accuracy
plt.subplot(1, 2, 2)
plt.plot(cnn_history_dict['accuracy'], label='Training Accuracy', color='green', marker='o')
plt.plot(cnn_history_dict['val_accuracy'], label='Validation Accuracy', color='red', marker='o')
plt.title('CNN Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)

# Show the plots
plt.tight_layout()
plt.show()

```


    
![png](output_26_0.png)
    


## Saving the model


```python
model.save('gender_classification_model_v22.model')
```

    INFO:tensorflow:Assets written to: gender_classification_model_v22.model\assets
    

    INFO:tensorflow:Assets written to: gender_classification_model_v22.model\assets
    

# VGG16 Model

## Initialization of VGG16 Base Model with Pre-trained Weights


```python
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(img_width, img_height, 3))
```

## Freezing Layers in the Base Model


```python
for layer in base_model.layers:
    layer.trainable = False
```

## Custom Classifier Layer on Top of Base Model


```python
model = Flatten()(base_model.output)
model = Dense(512, activation='relu')(model)
model = Dropout(0.5)(model)
model = Dense(1, activation='sigmoid')(model)
```

## Creating the final model


```python
vgg16_model = Model(inputs=base_model.input, outputs=model)
```

## Model Optimization and compilation


```python
opt = tf.keras.optimizers.legacy.Adam(learning_rate=1e-4, decay=1e-4 / epochs)
vgg16_model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
```

## Model Training


```python
vgg16_history = vgg16_model.fit(train_generator, epochs=epochs, validation_data=test_generator, callbacks=[lr_scheduler])
```

    Epoch 1/35
    242/242 [==============================] - 1368s 6s/step - loss: 0.3382 - accuracy: 0.8548 - val_loss: 0.3919 - val_accuracy: 0.8373 - lr: 0.0010
    Epoch 2/35
    242/242 [==============================] - 1437s 6s/step - loss: 0.2421 - accuracy: 0.9013 - val_loss: 0.3662 - val_accuracy: 0.8526 - lr: 0.0010
    Epoch 3/35
    242/242 [==============================] - 1425s 6s/step - loss: 0.2250 - accuracy: 0.9100 - val_loss: 0.5113 - val_accuracy: 0.7964 - lr: 0.0010
    Epoch 4/35
    242/242 [==============================] - 1437s 6s/step - loss: 0.2099 - accuracy: 0.9171 - val_loss: 0.3110 - val_accuracy: 0.8775 - lr: 0.0010
    Epoch 5/35
    242/242 [==============================] - 1437s 6s/step - loss: 0.1972 - accuracy: 0.9218 - val_loss: 0.4107 - val_accuracy: 0.8423 - lr: 0.0010
    Epoch 6/35
    242/242 [==============================] - 1431s 6s/step - loss: 0.1897 - accuracy: 0.9257 - val_loss: 0.3700 - val_accuracy: 0.8609 - lr: 0.0010
    Epoch 7/35
    242/242 [==============================] - 1449s 6s/step - loss: 0.1796 - accuracy: 0.9303 - val_loss: 0.3127 - val_accuracy: 0.8816 - lr: 0.0010
    Epoch 8/35
    242/242 [==============================] - 1455s 6s/step - loss: 0.1723 - accuracy: 0.9353 - val_loss: 0.3390 - val_accuracy: 0.8733 - lr: 0.0010
    Epoch 9/35
    242/242 [==============================] - 1450s 6s/step - loss: 0.1678 - accuracy: 0.9357 - val_loss: 0.3228 - val_accuracy: 0.8788 - lr: 0.0010
    Epoch 10/35
    232/242 [===========================>..] - ETA: 53s - loss: 0.1525 - accuracy: 0.9421


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    Cell In[18], line 1
    ----> 1 vgg16_history = vgg16_model.fit(train_generator, epochs=epochs, validation_data=test_generator, callbacks=[lr_scheduler])
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\keras\src\utils\traceback_utils.py:65, in filter_traceback.<locals>.error_handler(*args, **kwargs)
         63 filtered_tb = None
         64 try:
    ---> 65     return fn(*args, **kwargs)
         66 except Exception as e:
         67     filtered_tb = _process_traceback_frames(e.__traceback__)
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\keras\src\engine\training.py:1783, in Model.fit(self, x, y, batch_size, epochs, verbose, callbacks, validation_split, validation_data, shuffle, class_weight, sample_weight, initial_epoch, steps_per_epoch, validation_steps, validation_batch_size, validation_freq, max_queue_size, workers, use_multiprocessing)
       1775 with tf.profiler.experimental.Trace(
       1776     "train",
       1777     epoch_num=epoch,
       (...)
       1780     _r=1,
       1781 ):
       1782     callbacks.on_train_batch_begin(step)
    -> 1783     tmp_logs = self.train_function(iterator)
       1784     if data_handler.should_sync:
       1785         context.async_wait()
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\util\traceback_utils.py:150, in filter_traceback.<locals>.error_handler(*args, **kwargs)
        148 filtered_tb = None
        149 try:
    --> 150   return fn(*args, **kwargs)
        151 except Exception as e:
        152   filtered_tb = _process_traceback_frames(e.__traceback__)
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\polymorphic_function\polymorphic_function.py:831, in Function.__call__(self, *args, **kwds)
        828 compiler = "xla" if self._jit_compile else "nonXla"
        830 with OptionalXlaContext(self._jit_compile):
    --> 831   result = self._call(*args, **kwds)
        833 new_tracing_count = self.experimental_get_tracing_count()
        834 without_tracing = (tracing_count == new_tracing_count)
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\polymorphic_function\polymorphic_function.py:867, in Function._call(self, *args, **kwds)
        864   self._lock.release()
        865   # In this case we have created variables on the first call, so we run the
        866   # defunned version which is guaranteed to never create variables.
    --> 867   return tracing_compilation.call_function(
        868       args, kwds, self._no_variable_creation_config
        869   )
        870 elif self._variable_creation_config is not None:
        871   # Release the lock early so that multiple threads can perform the call
        872   # in parallel.
        873   self._lock.release()
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\polymorphic_function\tracing_compilation.py:139, in call_function(args, kwargs, tracing_options)
        137 bound_args = function.function_type.bind(*args, **kwargs)
        138 flat_inputs = function.function_type.unpack_inputs(bound_args)
    --> 139 return function._call_flat(  # pylint: disable=protected-access
        140     flat_inputs, captured_inputs=function.captured_inputs
        141 )
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\polymorphic_function\concrete_function.py:1264, in ConcreteFunction._call_flat(self, tensor_inputs, captured_inputs)
       1260 possible_gradient_type = gradients_util.PossibleTapeGradientTypes(args)
       1261 if (possible_gradient_type == gradients_util.POSSIBLE_GRADIENT_TYPES_NONE
       1262     and executing_eagerly):
       1263   # No tape is watching; skip to running the function.
    -> 1264   return self._inference_function.flat_call(args)
       1265 forward_backward = self._select_forward_and_backward_functions(
       1266     args,
       1267     possible_gradient_type,
       1268     executing_eagerly)
       1269 forward_function, args_with_tangents = forward_backward.forward()
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\polymorphic_function\atomic_function.py:217, in AtomicFunction.flat_call(self, args)
        215 def flat_call(self, args: Sequence[core.Tensor]) -> Any:
        216   """Calls with tensor inputs and returns the structured output."""
    --> 217   flat_outputs = self(*args)
        218   return self.function_type.pack_output(flat_outputs)
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\polymorphic_function\atomic_function.py:252, in AtomicFunction.__call__(self, *args)
        250 with record.stop_recording():
        251   if self._bound_context.executing_eagerly():
    --> 252     outputs = self._bound_context.call_function(
        253         self.name,
        254         list(args),
        255         len(self.function_type.flat_outputs),
        256     )
        257   else:
        258     outputs = make_call_op_in_graph(
        259         self,
        260         list(args),
        261         self._bound_context.function_call_options.as_attrs(),
        262     )
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\context.py:1479, in Context.call_function(self, name, tensor_inputs, num_outputs)
       1477 cancellation_context = cancellation.context()
       1478 if cancellation_context is None:
    -> 1479   outputs = execute.execute(
       1480       name.decode("utf-8"),
       1481       num_outputs=num_outputs,
       1482       inputs=tensor_inputs,
       1483       attrs=attrs,
       1484       ctx=self,
       1485   )
       1486 else:
       1487   outputs = execute.execute_with_cancellation(
       1488       name.decode("utf-8"),
       1489       num_outputs=num_outputs,
       (...)
       1493       cancellation_manager=cancellation_context,
       1494   )
    

    File D:\Jupyter\data science project\genderClassification\lib\site-packages\tensorflow\python\eager\execute.py:60, in quick_execute(op_name, num_outputs, inputs, attrs, ctx, name)
         53   # Convert any objects of type core_types.Tensor to Tensor.
         54   inputs = [
         55       tensor_conversion_registry.convert(t)
         56       if isinstance(t, core_types.Tensor)
         57       else t
         58       for t in inputs
         59   ]
    ---> 60   tensors = pywrap_tfe.TFE_Py_Execute(ctx._handle, device_name, op_name,
         61                                       inputs, attrs, num_outputs)
         62 except core._NotOkStatusException as e:
         63   if name is not None:
    

    KeyboardInterrupt: 


I did not train the model fully due to its extensive time consumption.

## Plotting the training and validation accuracy and loss of the VGG16 model


```python
# Number of epochs
epochs = list(range(1, 11))

# ELost the data so created list
training_loss = [0.3382, 0.2421, 0.2250, 0.2099, 0.1972, 0.1897, 0.1796, 0.1723, 0.1678, 0.1525]
training_accuracy = [0.8548, 0.9013, 0.9100, 0.9171, 0.9218, 0.9257, 0.9303, 0.9353, 0.9357, 0.9421]

validation_loss = [0.3919, 0.3662, 0.5113, 0.3110, 0.4107, 0.3700, 0.3127, 0.3390, 0.3228, 0.3184]
validation_accuracy = [0.8373, 0.8526, 0.7964, 0.8775, 0.8423, 0.8609, 0.8816, 0.8733, 0.8788, 0.8852]

# Plot the training and validation loss
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1)
plt.plot(epochs, training_loss, label='Training Loss', color='blue', marker='o')
plt.plot(epochs, validation_loss, label='Validation Loss', color='orange', marker='o')
plt.title('VGG16 Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)

# Plot the training and validation accuracy
plt.subplot(1, 2, 2)
plt.plot(epochs, training_accuracy, label='Training Accuracy', color='green', marker='o')
plt.plot(epochs, validation_accuracy, label='Validation Accuracy', color='red', marker='o')
plt.title('VGG16 Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)

# Show the plots
plt.tight_layout()
plt.show()

```


    
![png](output_44_0.png)
    


## Saving the model


```python
vgg16_model.save('gender_classification_vgg16_model.model')
```

    INFO:tensorflow:Assets written to: gender_classification_vgg16_model.model\assets
    

    INFO:tensorflow:Assets written to: gender_classification_vgg16_model.model\assets
    

## ResNet Model

## Load Pre-trained ResNet50 Model with ImageNet Weights


```python
base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(img_width, img_height, 3))
```

    Downloading data from https://storage.googleapis.com/tensorflow/keras-applications/resnet/resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5
    94765736/94765736 [==============================] - 8s 0us/step
    

## Freeze Layers in the ResNet50 Model to Retain Pre-trained Weights


```python
for layer in base_model.layers:
    layer.trainable = False
```

## Customize Fully Connected Layers for Gender Classification on Top of ResNet50 Base Model


```python
model = Flatten()(base_model.output)
model = Dense(512, activation='relu')(model)
model = Dropout(0.5)(model)
model = Dense(1, activation='sigmoid')(model)
```

## Create ResNet50-based Model for Gender Classification


```python
resnet_model = Model(inputs=base_model.input, outputs=model)
```

## Model Optimization and Compilation


```python
opt = tf.keras.optimizers.legacy.Adam(lr=1e-4, decay=1e-4 / epochs)
resnet_model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])

```

## Model Training


```python
resnet_history = resnet_model.fit(train_generator, epochs=epochs, validation_data=test_generator, callbacks=[lr_scheduler])
```

    Epoch 1/35
    242/242 [==============================] - 574s 2s/step - loss: 0.6462 - accuracy: 0.6325 - val_loss: 0.5850 - val_accuracy: 0.6887 - lr: 0.0010
    Epoch 2/35
    242/242 [==============================] - 600s 2s/step - loss: 0.5735 - accuracy: 0.7038 - val_loss: 0.5879 - val_accuracy: 0.6706 - lr: 0.0010
    Epoch 3/35
    242/242 [==============================] - 563s 2s/step - loss: 0.5484 - accuracy: 0.7272 - val_loss: 0.5280 - val_accuracy: 0.7376 - lr: 0.0010
    Epoch 4/35
    242/242 [==============================] - 571s 2s/step - loss: 0.5339 - accuracy: 0.7374 - val_loss: 0.5245 - val_accuracy: 0.7353 - lr: 0.0010
    Epoch 5/35
    242/242 [==============================] - 578s 2s/step - loss: 0.5236 - accuracy: 0.7459 - val_loss: 0.5607 - val_accuracy: 0.7146 - lr: 0.0010
    Epoch 6/35
    242/242 [==============================] - 597s 2s/step - loss: 0.5134 - accuracy: 0.7529 - val_loss: 0.5251 - val_accuracy: 0.7617 - lr: 0.0010
    Epoch 7/35
    242/242 [==============================] - 573s 2s/step - loss: 0.5057 - accuracy: 0.7594 - val_loss: 0.5272 - val_accuracy: 0.7407 - lr: 0.0010
    Epoch 8/35
    242/242 [==============================] - 611s 3s/step - loss: 0.4979 - accuracy: 0.7627 - val_loss: 0.4933 - val_accuracy: 0.7679 - lr: 0.0010
    Epoch 9/35
    242/242 [==============================] - 596s 2s/step - loss: 0.4860 - accuracy: 0.7747 - val_loss: 0.4862 - val_accuracy: 0.7679 - lr: 0.0010
    Epoch 10/35
    242/242 [==============================] - 574s 2s/step - loss: 0.4952 - accuracy: 0.7687 - val_loss: 0.5010 - val_accuracy: 0.7607 - lr: 0.0010
    Epoch 11/35
    242/242 [==============================] - 598s 2s/step - loss: 0.4964 - accuracy: 0.7638 - val_loss: 0.5020 - val_accuracy: 0.7643 - lr: 0.0010
    Epoch 12/35
    242/242 [==============================] - 569s 2s/step - loss: 0.4820 - accuracy: 0.7733 - val_loss: 0.4839 - val_accuracy: 0.7736 - lr: 0.0010
    Epoch 13/35
    242/242 [==============================] - 581s 2s/step - loss: 0.5033 - accuracy: 0.7508 - val_loss: 0.5227 - val_accuracy: 0.7617 - lr: 0.0010
    Epoch 14/35
    242/242 [==============================] - 619s 3s/step - loss: 0.5098 - accuracy: 0.7384 - val_loss: 0.5513 - val_accuracy: 0.7110 - lr: 0.0010
    Epoch 15/35
    242/242 [==============================] - 577s 2s/step - loss: 0.5054 - accuracy: 0.7446 - val_loss: 0.4913 - val_accuracy: 0.7731 - lr: 0.0010
    Epoch 16/35
    242/242 [==============================] - 610s 3s/step - loss: 0.4778 - accuracy: 0.7735 - val_loss: 0.4910 - val_accuracy: 0.7798 - lr: 0.0010
    Epoch 17/35
    242/242 [==============================] - 639s 3s/step - loss: 0.4816 - accuracy: 0.7605 - val_loss: 0.5128 - val_accuracy: 0.7516 - lr: 0.0010
    Epoch 18/35
    242/242 [==============================] - 592s 2s/step - loss: 0.4729 - accuracy: 0.7710 - val_loss: 0.4829 - val_accuracy: 0.7773 - lr: 0.0010
    Epoch 19/35
    242/242 [==============================] - 577s 2s/step - loss: 0.4788 - accuracy: 0.7700 - val_loss: 0.5122 - val_accuracy: 0.7646 - lr: 0.0010
    Epoch 20/35
    242/242 [==============================] - 593s 2s/step - loss: 0.4769 - accuracy: 0.7753 - val_loss: 0.4803 - val_accuracy: 0.7879 - lr: 0.0010
    Epoch 21/35
    242/242 [==============================] - 563s 2s/step - loss: 0.4749 - accuracy: 0.7695 - val_loss: 0.4871 - val_accuracy: 0.7705 - lr: 0.0010
    Epoch 22/35
    242/242 [==============================] - 677s 3s/step - loss: 0.4758 - accuracy: 0.7658 - val_loss: 0.5022 - val_accuracy: 0.7625 - lr: 9.0000e-04
    Epoch 23/35
    242/242 [==============================] - 648s 3s/step - loss: 0.4558 - accuracy: 0.7912 - val_loss: 0.5205 - val_accuracy: 0.7620 - lr: 9.0000e-04
    Epoch 24/35
    242/242 [==============================] - 643s 3s/step - loss: 0.4636 - accuracy: 0.7789 - val_loss: 0.4664 - val_accuracy: 0.7770 - lr: 9.0000e-04
    Epoch 25/35
    242/242 [==============================] - 571s 2s/step - loss: 0.4553 - accuracy: 0.7865 - val_loss: 0.4678 - val_accuracy: 0.7956 - lr: 9.0000e-04
    Epoch 26/35
    242/242 [==============================] - 596s 2s/step - loss: 0.4479 - accuracy: 0.7892 - val_loss: 0.4800 - val_accuracy: 0.7928 - lr: 9.0000e-04
    Epoch 27/35
    242/242 [==============================] - 562s 2s/step - loss: 0.4581 - accuracy: 0.7840 - val_loss: 0.4676 - val_accuracy: 0.7936 - lr: 9.0000e-04
    Epoch 28/35
    242/242 [==============================] - 567s 2s/step - loss: 0.4404 - accuracy: 0.7919 - val_loss: 0.4656 - val_accuracy: 0.7923 - lr: 9.0000e-04
    Epoch 29/35
    242/242 [==============================] - 580s 2s/step - loss: 0.4449 - accuracy: 0.7872 - val_loss: 0.4559 - val_accuracy: 0.7954 - lr: 9.0000e-04
    Epoch 30/35
    242/242 [==============================] - 575s 2s/step - loss: 0.4353 - accuracy: 0.7956 - val_loss: 0.4680 - val_accuracy: 0.7985 - lr: 7.0000e-04
    Epoch 31/35
    242/242 [==============================] - 569s 2s/step - loss: 0.4397 - accuracy: 0.7950 - val_loss: 0.5038 - val_accuracy: 0.7685 - lr: 7.0000e-04
    Epoch 32/35
    242/242 [==============================] - 576s 2s/step - loss: 0.4331 - accuracy: 0.7924 - val_loss: 0.4691 - val_accuracy: 0.8016 - lr: 7.0000e-04
    Epoch 33/35
    242/242 [==============================] - 605s 3s/step - loss: 0.4345 - accuracy: 0.7996 - val_loss: 0.4887 - val_accuracy: 0.7889 - lr: 7.0000e-04
    Epoch 34/35
    242/242 [==============================] - 615s 3s/step - loss: 0.4287 - accuracy: 0.8011 - val_loss: 0.5070 - val_accuracy: 0.7848 - lr: 5.0000e-04
    Epoch 35/35
    242/242 [==============================] - 569s 2s/step - loss: 0.4297 - accuracy: 0.8015 - val_loss: 0.4740 - val_accuracy: 0.7938 - lr: 5.0000e-04
    

## Saving the trained model


```python
resnet_model.save('gender_classification_resnet_model.model')
```

    INFO:tensorflow:Assets written to: gender_classification_resnet_model.model\assets
    

    INFO:tensorflow:Assets written to: gender_classification_resnet_model.model\assets
    

## Plotting the training and validation accuracy and loss of the ResNet model


```python
# Set a seaborn style
sns.set(style="whitegrid")

# Access the training history
resnet_history_dict = resnet_history.history

# Plotting the training and validation loss
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1)
plt.plot(resnet_history_dict['loss'], label='Training Loss', color='blue', marker='o')
plt.plot(resnet_history_dict['val_loss'], label='Validation Loss', color='orange', marker='o')
plt.title('ResNet Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)

# Plotting the training and validation accuracy
plt.subplot(1, 2, 2)
plt.plot(resnet_history_dict['accuracy'], label='Training Accuracy', color='green', marker='o')
plt.plot(resnet_history_dict['val_accuracy'], label='Validation Accuracy', color='red', marker='o')
plt.title('ResNet Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)

# Show the plots
plt.tight_layout()
plt.show()

```


    
![png](output_63_0.png)
    


## CNN Model Assessing


```python
# Directory containing the test images
test_data_dir = "D:\Jupyter\Data Science Project\genderClassification\I don't know\Test"  # Replace with the path to your test data directory
img_width, img_height = 96, 96  # Adjust based on your image dimensions
batch_size = 64

# Create a data generator for the test set
test_datagen = ImageDataGenerator(rescale=1./255)
test_generator = test_datagen.flow_from_directory(
    test_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='binary',  # Adjust based on your problem (binary or categorical)
    shuffle=False  # Set to False for evaluation
)

# Load your pre-trained VGG16 model
cnn_model = load_model('gender_classification_model_v22.model')  # Replace with the path to your VGG16 model

# Initialize lists to store true labels and predicted labels
y_true = []
y_pred = []

# Iterate over subdirectories (Man and Woman)
for class_label in ['Man', 'Woman']:
    class_path = os.path.join(test_data_dir, class_label)

    # Check if it's a directory
    if os.path.isdir(class_path):
        # List all image files in the subdirectory
        image_files = [os.path.join(class_path, f) for f in os.listdir(class_path) if f.endswith(('.jpg', '.jpeg', '.png'))]

        # Select 302 images from each subdirectory
        image_files = image_files[:302]

        # Iterate over test images
        for img_path in image_files:
            # Load and preprocess the image
            img = load_img(img_path, target_size=(img_width, img_height))
            img_array = img_to_array(img) / 255.0
            img_array = np.expand_dims(img_array, axis=0)

            # Predict the gender using the VGG16 model
            prediction = cnn_model.predict(img_array, verbose=0)[0]
            predicted_label = 1 if prediction[0] > 0.5 else 0

            # Extract the true label from the subdirectory name
            true_label = 1 if class_label == 'Woman' else 0

            # Append true and predicted labels to the lists
            y_true.append(true_label)
            y_pred.append(predicted_label)

# Convert lists to NumPy arrays
y_true = np.array(y_true)
y_pred = np.array(y_pred)

# Compute the confusion matrix
cm = confusion_matrix(y_true, y_pred)

# Plot the confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Man", "Woman"],
            yticklabels=["Man", "Woman"])
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.show()

```

    Found 496 images belonging to 2 classes.
    


    
![png](output_65_1.png)
    



```python
# Print Classification Report
print("Classification Report:")
print(classification_report(y_true, y_pred, target_names=["Man", "Woman"]))
```

    Classification Report:
                  precision    recall  f1-score   support
    
             Man       0.99      0.66      0.79       247
           Woman       0.74      0.99      0.85       249
    
        accuracy                           0.82       496
       macro avg       0.87      0.82      0.82       496
    weighted avg       0.87      0.82      0.82       496
    
    

## VGG16 Model Assessing


```python
# Directory containing the test images
test_data_dir = "D:\Jupyter\Data Science Project\genderClassification\I don't know\Test"  # Replace with the path to your test data directory
img_width, img_height = 96, 96  # Adjust based on your image dimensions
batch_size = 64

# Create a data generator for the test set
test_datagen = ImageDataGenerator(rescale=1./255)
test_generator = test_datagen.flow_from_directory(
    test_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='binary',  # Adjust based on your problem (binary or categorical)
    shuffle=False  # Set to False for evaluation
)

# Load your pre-trained VGG16 model
vgg16_model = load_model('gender_classification_vgg16_model.model')  # Replace with the path to your VGG16 model

# Initialize lists to store true labels and predicted labels
y_true = []
y_pred = []

# Iterate over subdirectories (Man and Woman)
for class_label in ['Man', 'Woman']:
    class_path = os.path.join(test_data_dir, class_label)

    # Check if it's a directory
    if os.path.isdir(class_path):
        # List all image files in the subdirectory
        image_files = [os.path.join(class_path, f) for f in os.listdir(class_path) if f.endswith(('.jpg', '.jpeg', '.png'))]

        # Select 302 images from each subdirectory
        image_files = image_files[:302]

        # Iterate over test images
        for img_path in image_files:
            # Load and preprocess the image
            img = load_img(img_path, target_size=(img_width, img_height))
            img_array = img_to_array(img) / 255.0
            img_array = np.expand_dims(img_array, axis=0)

            # Predict the gender using the VGG16 model
            prediction = vgg16_model.predict(img_array,verbose=0)[0]
            predicted_label = 1 if prediction[0] > 0.5 else 0

            # Extract the true label from the subdirectory name
            true_label = 1 if class_label == 'Woman' else 0

            # Append true and predicted labels to the lists
            y_true.append(true_label)
            y_pred.append(predicted_label)

# Convert lists to NumPy arrays
y_true = np.array(y_true)
y_pred = np.array(y_pred)

# Compute the confusion matrix
cm = confusion_matrix(y_true, y_pred)

# Plot the confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Man", "Woman"],
            yticklabels=["Man", "Woman"])
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.show()
```

    Found 496 images belonging to 2 classes.
    


    
![png](output_68_1.png)
    



```python
# Print Classification Report
print("Classification Report:")
print(classification_report(y_true, y_pred, target_names=["Man", "Woman"]))
```

    Classification Report:
                  precision    recall  f1-score   support
    
             Man       0.91      0.86      0.88       247
           Woman       0.87      0.92      0.89       249
    
        accuracy                           0.89       496
       macro avg       0.89      0.89      0.89       496
    weighted avg       0.89      0.89      0.89       496
    
    

## ResNet Model Assessing


```python
# Directory containing the test images
test_data_dir = "D:\Jupyter\Data Science Project\genderClassification\I don't know\Test"  # Replace with the path to your test data directory
img_width, img_height = 96, 96  # Adjust based on your image dimensions
batch_size = 64

# Create a data generator for the test set
test_datagen = ImageDataGenerator(rescale=1./255)
test_generator = test_datagen.flow_from_directory(
    test_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='binary',  # Adjust based on your problem (binary or categorical)
    shuffle=False  # Set to False for evaluation
)

# Load your pre-trained VGG16 model
resnet_model = load_model('gender_classification_resnet_model.model')  # Replace with the path to your VGG16 model

# Initialize lists to store true labels and predicted labels
y_true = []
y_pred = []

# Iterate over subdirectories (Man and Woman)
for class_label in ['Man', 'Woman']:
    class_path = os.path.join(test_data_dir, class_label)

    # Check if it's a directory
    if os.path.isdir(class_path):
        # List all image files in the subdirectory
        image_files = [os.path.join(class_path, f) for f in os.listdir(class_path) if f.endswith(('.jpg', '.jpeg', '.png'))]

        # Select 302 images from each subdirectory
        image_files = image_files[:302]

        # Iterate over test images
        for img_path in image_files:
            # Load and preprocess the image
            img = load_img(img_path, target_size=(img_width, img_height))
            img_array = img_to_array(img) / 255.0
            img_array = np.expand_dims(img_array, axis=0)

            # Predict the gender using the VGG16 model
            prediction = resnet_model.predict(img_array,verbose=0)[0]
            predicted_label = 1 if prediction[0] > 0.5 else 0

            # Extract the true label from the subdirectory name
            true_label = 1 if class_label == 'Woman' else 0

            # Append true and predicted labels to the lists
            y_true.append(true_label)
            y_pred.append(predicted_label)

# Convert lists to NumPy arrays
y_true = np.array(y_true)
y_pred = np.array(y_pred)

# Compute the confusion matrix
cm = confusion_matrix(y_true, y_pred)

# Plot the confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Man", "Woman"],
            yticklabels=["Man", "Woman"])
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.show()

```

    Found 496 images belonging to 2 classes.
    


    
![png](output_71_1.png)
    



```python
# Print Classification Report
print("Classification Report:")
print(classification_report(y_true, y_pred, target_names=["Man", "Woman"]))
```

    Classification Report:
                  precision    recall  f1-score   support
    
             Man       0.74      0.47      0.58       247
           Woman       0.61      0.84      0.71       249
    
        accuracy                           0.66       496
       macro avg       0.68      0.65      0.64       496
    weighted avg       0.68      0.66      0.64       496
    
    

## Implementing the model on realtime webcam

The model for the below code can be changed at will


```python
# Load your trained model
model = load_model('gender_classification_model_v22.model')  # Replace with the path to your trained model

# Load the face cascade for detecting faces
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Open the webcam
webcam = cv2.VideoCapture(0)

while True:
    # Read a frame from the webcam
    _, frame = webcam.read()

    # Convert the frame to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    # Iterate over detected faces
    for (x, y, w, h) in faces:
        # Crop the face region
        face_roi = frame[y:y+h, x:x+w]

        # Resize the face to the required input dimensions for your model
        face_roi = cv2.resize(face_roi, (96, 96))

        # Normalize pixel values and convert to array
        face_array = img_to_array(face_roi) / 255.0
        face_array = np.expand_dims(face_array, axis=0)

        # Use the trained model for gender classification
        prediction = model.predict(face_array)[0]
        gender = "Man" if prediction < 0.5 else "Woman"

        # Display the gender label on the frame
        cv2.putText(frame, f"Gender: {gender}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        
        # Draw a rectangle around the face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Display the frame
    cv2.imshow("Gender Classification", frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close all OpenCV windows
webcam.release()
cv2.destroyAllWindows()

```

    1/1 [==============================] - 0s 207ms/step
    1/1 [==============================] - 0s 56ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 42ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 50ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 56ms/step
    1/1 [==============================] - 0s 50ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 53ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 42ms/step
    1/1 [==============================] - 0s 51ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 190ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 51ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 48ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 48ms/step
    1/1 [==============================] - 0s 48ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 53ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 51ms/step
    1/1 [==============================] - 0s 53ms/step
    1/1 [==============================] - 0s 48ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 42ms/step
    1/1 [==============================] - 0s 42ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 80ms/step
    1/1 [==============================] - 0s 67ms/step
    1/1 [==============================] - 0s 81ms/step
    1/1 [==============================] - 0s 69ms/step
    1/1 [==============================] - 0s 53ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 50ms/step
    1/1 [==============================] - 0s 43ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 50ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 48ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 51ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 48ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 48ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 58ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 45ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 47ms/step
    1/1 [==============================] - 0s 50ms/step
    1/1 [==============================] - 0s 52ms/step
    1/1 [==============================] - 0s 46ms/step
    1/1 [==============================] - 0s 49ms/step
    1/1 [==============================] - 0s 44ms/step
    1/1 [==============================] - 0s 48ms/step
    
